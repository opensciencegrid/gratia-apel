'''
Created on 13 Dec 2011

@author: will
'''

import get_brokers

import unittest


class Test(unittest.TestCase):


    def setUp(self):
        pass


    def tearDown(self):
        pass


    def test_parse_stomp_url(self):
        
        wrong_url = "this is not a correct url"
        try:
            get_brokers.parse_stomp_url(wrong_url)
            self.fail("Appeared to parse a fake URL.")
        except (IndexError, ValueError):
            # Expected exception
            pass
            
        http_url = "http://not.a.stomp.url:8080"
        
        try:
            get_brokers.parse_stomp_url(http_url)
            self.fail("Parsed a URL which was not STOMP.")
        except ValueError:
            pass
        
        stomp_url = "stomp://stomp.cern.ch:6262"
        
        try:
            get_brokers.parse_stomp_url(stomp_url)
        except:
            self.fail("Could not parse a valid stomp URL: %s" % stomp_url)        
        

        stomp_ssl_url = "stomp+ssl://stomp.cern.ch:61262"
        
        try:
            get_brokers.parse_stomp_url(stomp_ssl_url)
        except:
            self.fail("Could not parse a valid stomp+ssl URL: %s" % stomp_url)        
            
    def test_broker_in_network(self):
        '''
        This method failed when the LDAP search returned an empty list.
        '''
        class DummyLdapConn(object):
            def search_s(self, arg1, arg2, arg3, arg4):
                return []
        
        # Hack: have to use a real URL so that the object is created. I 
        # would rather not need a network connection.
        bg = get_brokers.StompBrokerGetter("ldap://lcg-bdii.cern.ch:2170")
        bg._ldap_conn = DummyLdapConn()
        
        assert bg._broker_in_network("broker1", "network") == False
        
        

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()